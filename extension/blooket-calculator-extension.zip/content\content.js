function m(){if(document.getElementById("blooket-calc-widget"))return;const o=document.createElement("div");o.id="blooket-calc-widget",o.style.cssText="position:fixed;bottom:20px;right:20px;z-index:999999;pointer-events:auto;font-family:Inter,system-ui,sans-serif;",document.body.appendChild(o),o.innerHTML=`
    <div id="bcw-panel" style="width:280px;border-radius:16px;border:1px solid rgba(255,255,255,0.1);background:rgba(10,14,26,0.95);backdrop-filter:blur(20px);box-shadow:0 25px 50px rgba(0,0,0,0.5);overflow:hidden;">
      <div id="bcw-header" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.06);cursor:move;">
        <div style="display:flex;align-items:center;gap:8px;">
          <div style="width:24px;height:24px;border-radius:6px;background:linear-gradient(135deg,#8b5cf6,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:900;color:white;">B</div>
          <span style="font-size:12px;font-weight:600;color:white;">Blooket Calculator</span>
        </div>
        <div style="display:flex;gap:4px;">
          <button id="bcw-min" style="background:none;border:none;color:rgba(255,255,255,0.6);cursor:pointer;padding:2px;font-size:14px;">−</button>
          <button id="bcw-close" style="background:none;border:none;color:rgba(255,255,255,0.6);cursor:pointer;padding:2px;font-size:14px;">×</button>
        </div>
      </div>
      <div id="bcw-body" style="padding:12px;">
        <div style="margin-bottom:8px;">
          <label style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.2em;color:#8b5cf6;display:block;margin-bottom:4px;">Tokens</label>
          <input id="bcw-tokens" type="number" value="500" min="0" style="width:100%;border-radius:10px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02);padding:8px 12px;font-size:14px;font-weight:700;color:white;outline:none;font-family:inherit;" />
        </div>
        <div style="margin-bottom:8px;">
          <label style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.2em;color:#8b5cf6;display:block;margin-bottom:4px;">Pack</label>
          <select id="bcw-pack" style="width:100%;border-radius:10px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.02);padding:8px 12px;font-size:12px;color:white;outline:none;font-family:inherit;">
            <option value="space">Space (20 tkn)</option>
            <option value="medieval">Medieval (20 tkn)</option>
            <option value="aquatic">Aquatic (20 tkn)</option>
            <option value="lunch">Lunch (25 tkn)</option>
            <option value="bug">Bug (25 tkn)</option>
            <option value="pirate">Pirate (25 tkn)</option>
            <option value="breakfast">Breakfast (20 tkn)</option>
            <option value="bot">Bot (20 tkn)</option>
            <option value="safari">Safari (20 tkn)</option>
            <option value="dino">Dino (25 tkn)</option>
            <option value="wonderland">Wonderland (20 tkn)</option>
            <option value="outback">Outback (25 tkn)</option>
            <option value="ice-monster">Ice Monster (25 tkn)</option>
          </select>
        </div>
        <div style="display:flex;gap:4px;margin-bottom:10px;">
          <button class="bcw-metric" data-m="epicPlus" style="flex:1;border-radius:8px;padding:6px;font-size:10px;font-weight:600;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.02);color:rgba(255,255,255,0.6);cursor:pointer;">Epic+</button>
          <button class="bcw-metric" data-m="legendary" style="flex:1;border-radius:8px;padding:6px;font-size:10px;font-weight:600;border:1px solid rgba(99,102,241,0.4);background:rgba(99,102,241,0.1);color:#a5b4fc;cursor:pointer;">Legendary</button>
          <button class="bcw-metric" data-m="chroma" style="flex:1;border-radius:8px;padding:6px;font-size:10px;font-weight:600;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.02);color:rgba(255,255,255,0.6);cursor:pointer;">Chroma</button>
        </div>
        <div id="bcw-result" style="text-align:center;padding:8px 0;border-top:1px solid rgba(255,255,255,0.06);">
          <div id="bcw-pct" style="font-size:28px;font-weight:900;color:#5eead4;">—</div>
          <div id="bcw-label" style="font-size:10px;color:rgba(255,255,255,0.5);margin-top:2px;">chance in 0 pulls</div>
        </div>
        <a id="bcw-full" href="https://www.calculatorblooket.com/?utm_source=extension&utm_medium=widget&utm_campaign=v1" target="_blank" style="display:block;width:100%;border-radius:10px;background:linear-gradient(135deg,#8b5cf6,#7c3aed);padding:8px;text-align:center;font-size:11px;font-weight:600;color:white;text-decoration:none;margin-top:8px;">Open Full Calculator →</a>
      </div>
    </div>
  `;let d=!1,c=0,p=0,s=0,b=0;const x=document.getElementById("bcw-header"),y=document.getElementById("bcw-panel"),f=document.getElementById("bcw-body");x.addEventListener("mousedown",e=>{d=!0,c=e.clientX,p=e.clientY;const n=o.getBoundingClientRect();s=n.left,b=n.top,e.preventDefault()}),document.addEventListener("mousemove",e=>{if(!d)return;const n=e.clientX-c,t=e.clientY-p;o.style.left=`${s+n}px`,o.style.top=`${b+t}px`,o.style.right="auto",o.style.bottom="auto"}),document.addEventListener("mouseup",()=>{d=!1});let i=!1;document.getElementById("bcw-min").addEventListener("click",()=>{i=!i,f.style.display=i?"none":"block",y.style.width=i?"auto":"280px"}),document.getElementById("bcw-close").addEventListener("click",()=>{o.style.display="none";const e=document.createElement("button");e.style.cssText="position:fixed;bottom:20px;right:20px;z-index:999999;border-radius:50%;background:linear-gradient(135deg,#8b5cf6,#7c3aed);border:none;padding:12px;cursor:pointer;box-shadow:0 4px 20px rgba(139,92,246,0.4);",e.innerHTML='<span style="font-size:18px;color:white;font-weight:900;">B</span>',e.addEventListener("click",()=>{o.style.display="block",e.remove()}),document.body.appendChild(e)});let l="legendary";document.querySelectorAll(".bcw-metric").forEach(e=>{e.addEventListener("click",()=>{l=e.dataset.m??"legendary",document.querySelectorAll(".bcw-metric").forEach(n=>{const t=n;t.dataset.m===l?(t.style.borderColor="rgba(99,102,241,0.4)",t.style.background="rgba(99,102,241,0.1)",t.style.color="#a5b4fc"):(t.style.borderColor="rgba(255,255,255,0.06)",t.style.background="rgba(255,255,255,0.02)",t.style.color="rgba(255,255,255,0.6)")}),r()})});const u=document.getElementById("bcw-tokens"),a=document.getElementById("bcw-pack");function r(){const e=Number(u.value)||0,n=a.value;chrome.runtime.sendMessage({type:"calc",tokens:e,packId:n,metric:l},t=>{t&&(document.getElementById("bcw-pct").textContent=t.pct,document.getElementById("bcw-label").textContent=`chance in ${t.pulls} pulls`)})}u.addEventListener("input",r),a.addEventListener("change",r);const g=window.location.pathname.match(/\/market\/(\w[\w-]*)/);if(g){const e=g[1];a.querySelector(`option[value="${e}"]`)&&(a.value=e)}r()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",m):m();
